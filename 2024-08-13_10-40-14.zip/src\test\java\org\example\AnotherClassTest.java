package org.example;

import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.Test;

public class AnotherClassTest {

    AnotherClass anotherClass = new AnotherClass();

    @Test
    void testGetLength() {
        assertEquals(5, anotherClass.getLength("Hello"));
        assertEquals(0, anotherClass.getLength(""));
    }

    @Test
    void testToUpperCase() {
        assertEquals("HELLO", anotherClass.toUpperCase("hello"));
        assertEquals("JAVA", anotherClass.toUpperCase("Java"));
    }

    @Test
    void testIsEmpty() {
        assertTrue(anotherClass.isEmpty(""));
        assertFalse(anotherClass.isEmpty("Not empty"));
    }
}
