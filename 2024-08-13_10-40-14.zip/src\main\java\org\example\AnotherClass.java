package org.example;

public class AnotherClass {

    // Método que devuelve la longitud de una cadena
    public int getLength(String str) {
        return str.length();
    }

    // Método que convierte una cadena a mayúsculas
    public String toUpperCase(String str) {
        return str.toUpperCase();
    }

    // Método que verifica si una cadena está vacía
    public boolean isEmpty(String str) {
        return str.isEmpty();
    }
}
