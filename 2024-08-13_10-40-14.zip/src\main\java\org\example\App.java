package org.example;

import java.util.logging.Logger;

public class App {
    // Crear un logger para la clase App
    private static final Logger logger = Logger.getLogger(App.class.getName());

    public static void main(String[] args) {
        AnotherClass anotherClass = new AnotherClass();

        // Usar logger en lugar de System.out.println para registrar mensajes
        logger.info("Length of 'Hello': " + anotherClass.getLength("Hello"));
        logger.info("'hello' in uppercase: " + anotherClass.toUpperCase("hello"));
        logger.info("Is 'Wrong' empty?: " + anotherClass.isEmpty("Wrong"));
    }
}
